### Descripción del Funcionamiento del Programa

Este programa es una herramienta gráfica diseñada para realizar operaciones de encriptación y desencriptación utilizando el algoritmo **AES (Advanced Encryption Standard)** combinado con codificación **Base64**. A continuación, se detalla su funcionamiento:

#### **Interfaz Gráfica de Usuario (GUI)**
La interfaz gráfica del programa permite al usuario interactuar de manera intuitiva con las funciones de encriptación y desencriptación. Incluye las siguientes características principales:
1. **Campos de Texto**:
   - **Texto para Encriptar**: Aquí el usuario puede introducir el texto que desea encriptar.
   - **Contraseña**: Este campo permite ingresar una contraseña necesaria tanto para encriptar como para desencriptar.
   - **Texto Encriptado**: Muestra el resultado del texto original convertido en Base64 después de aplicar el algoritmo AES.
   - **Texto Desencriptado**: Muestra el resultado de convertir el texto encriptado de vuelta a su formato original.

2. **Botones**:
   - **Encriptar**: Convierte el texto introducido en un formato cifrado y codificado en Base64 utilizando la contraseña proporcionada.
   - **Desencriptar**: Decodifica y descifra el texto encriptado de vuelta a su estado original, siempre y cuando se utilice la misma contraseña.
   - **Limpiar Campos**: Borra todos los campos de texto para permitir un nuevo proceso.
   - **Seleccionar Archivo para Codificar**: Permite seleccionar un archivo desde el sistema de archivos para convertir su contenido a Base64.

3. **Visualización del Log**:
   - Un área de texto muestra un registro (log) de las operaciones realizadas, incluyendo los textos encriptados y desencriptados, así como las contraseñas utilizadas (cuando corresponde).

4. **Aviso de Descargo de Responsabilidad**:
   - Antes de iniciar el programa, se muestra un mensaje emergente que informa al usuario sobre las limitaciones y riesgos del uso del software.

---

#### **Funcionalidades Adicionales**
1. **Codificación de Archivos en Base64**:
   - Permite seleccionar un archivo desde el sistema de archivos y codificar su contenido a Base64.
   - El resultado se guarda en un archivo de texto con un nombre único incremental (e.g., `encoded_file_00.txt`, `encoded_file_01.txt`).

2. **Control de Duplicados en el Log**:
   - Antes de añadir una nueva línea al registro (log), el programa verifica que no se duplique la información.

3. **Persistencia del Registro en un Archivo**:
   - Todo lo que aparece en el área del log se guarda automáticamente en un archivo de texto para referencia futura.

---

#### **Algoritmo de Cifrado**
1. **AES**:
   - Utiliza el algoritmo AES con modo CBC (Cipher Block Chaining) y un vector de inicialización (IV) fijo.
   - La clave de encriptación se genera dinámicamente a partir de la contraseña ingresada por el usuario mediante el uso de **PBKDF2WithHmacSHA256**.

2. **Base64**:
   - Los datos cifrados con AES se codifican en Base64 para facilitar su almacenamiento o transferencia como texto.

---

#### **Limitaciones**
- La seguridad depende de que el usuario utilice una contraseña fuerte.
- No se proporciona manejo avanzado de errores para contraseñas incorrectas o datos manipulados.
- El vector de inicialización (IV) es fijo, lo que puede limitar la seguridad en ciertos escenarios.

---

#### **Aplicaciones Prácticas**
1. **Protección de Información Sensible**:
   - Permite cifrar datos confidenciales para protegerlos frente a accesos no autorizados.
2. **Codificación de Archivos**:
   - Facilita la conversión de archivos binarios a un formato Base64 para compartir o almacenar de manera segura.
3. **Desencriptación de Datos**:
   - Proporciona una forma de recuperar información previamente cifrada siempre y cuando se cuente con la contraseña correcta.

Este programa es útil para tareas simples de encriptación y codificación, pero debe ser utilizado con precaución en escenarios donde se requiere alta seguridad.