import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.spec.KeySpec;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;


public class AESBase64EncryptDecryptGUI {
    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final String SECRET_KEY_ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final byte[] IV = new byte[16];
    private static final String LOG_FILE_PATH = "encryption_log.txt";

    public AESBase64EncryptDecryptGUI() {}

    private static JTextArea createStyledTextArea(String title) {
        JTextArea textArea = new JTextArea(3, 20);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), title, TitledBorder.LEFT, TitledBorder.TOP));
        return textArea;
    }

    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        return button;
    }

    private static void addComponentToFrame(JFrame frame, GridBagConstraints gbc, Component comp, int x, int y, int width, int height) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = width;
        gbc.gridheight = height;
        frame.add(comp, gbc);
    }

    public static String encrypt(String data, String password) throws Exception {
        SecretKey secretKey = generateSecretKey(password);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(IV));
        byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    
    /*
    public static String encryptNoPassword(String data) throws Exception {
        // Generate a random key
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256); // You can also use 128 or 192 bits
        SecretKey secretKey = keyGen.generateKey();

        // Initialize cipher with the generated key
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(IV));

        // Encrypt the data
        byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    */
    
    public static String encryptNoPassword(String data) {
        // Encode the data into Base64
        return Base64.getEncoder().encodeToString(data.getBytes(StandardCharsets.UTF_8));
    }



    public static String decrypt(String base64Data, String password) throws Exception {
        SecretKey secretKey = generateSecretKey(password);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(IV));
        byte[] decodedBytes = Base64.getDecoder().decode(base64Data);
        byte[] decryptedBytes = cipher.doFinal(decodedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }

    private static SecretKey generateSecretKey(String password) throws Exception {
        byte[] salt = "12345678".getBytes();
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 256);
        SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_ALGORITHM);
        byte[] secretKeyBytes = factory.generateSecret(spec).getEncoded();
        return new SecretKeySpec(secretKeyBytes, "AES");
    }

    private static void logOperation(String operation, String input, String output, String password) {
    	try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE_PATH, true))) {
    		String logEntry = operation + input + output + password;
    		if(isDuplicateLog(logEntry)) {
    			return;
    		}
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            writer.write("[" + timestamp + "] " + operation + " Operation:\n");
            writer.write("Password: " + password + "\n");
            writer.write("Input Text: " + input + "\n");
            writer.write("Output Text Base64: " + output + "\n");
            writer.write("---------------------------------------------------\n");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private static void clearAllFields(JTextArea inputTextArea, JTextArea encryptedTextArea, JTextArea decryptedTextArea, JPasswordField passwordField) {
        inputTextArea.setText("");
        encryptedTextArea.setText("");
        decryptedTextArea.setText("");
        passwordField.setText("");
    }
    //nOT WORKING
	private static boolean isDuplicateLog(String logEntry) {
	    try {
	        String logFilePath = LOG_FILE_PATH;
			// Check if the log file exists
	        if (!Files.exists(Paths.get(logFilePath))) {
	            return false; // No file means no duplicates.
	        }

	        // Read all lines from the log file
	        List<String> existingLogs = Files.readAllLines(Paths.get(logFilePath));

	        // Check if the logEntry is already present
	        return existingLogs.contains(logEntry);
	    } catch (IOException e) {
	        e.printStackTrace();
	        return false; // Default to no duplicates if there's an issue reading the file
	    }
	}
	
	public static String encodeFileToBase64(String filePath) {
	    try {
	        // Read the file's bytes
	        byte[] fileBytes = Files.readAllBytes(Paths.get(filePath));

	        // Encode the bytes to Base64
	        return Base64.getEncoder().encodeToString(fileBytes);
	    } catch (IOException e) {
	        e.printStackTrace();
	        return null; // Return null if an error occurs
	    }
	}
	
	public static void saveBase64ToFile(String base64Content, String outputFilePath) {
	    try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
	        writer.write(base64Content);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
    	
	  private static String getUniqueFileName(String baseFileName, String extension) {
          int counter = 0;
          String newFileName;

          do {
              newFileName = String.format("%s_%02d.%s", baseFileName, counter, extension);
              counter++;
          } while (Files.exists(Paths.get(newFileName)));

          return newFileName;
      }
	  
	 private static String decodeUnsaltedBase64(String base64Data) {
		    // Decode the Base64 string
		    byte[] decodedBytes = Base64.getDecoder().decode(base64Data);
		    return new String(decodedBytes, StandardCharsets.UTF_8); // Convert to string
	 }

	  
    public static void main(String[] args) {
    	String disclaimer = "DESCARGO DE RESPONSABILIDAD:\n\n"
                + "Este software se proporciona \"tal cual\", sin ninguna garantía expresa o implícita. "
                + "En ningún caso los desarrolladores serán responsables de ningún daño derivado del uso de este software.\n\n"
                + "No se proporciona soporte ni mantenimiento, y el uso de este programa es completamente bajo su propio riesgo.\n\n"
                + "Al continuar, usted acepta estos términos.\n\n"
                + "Haga clic en Aceptar para continuar.";


        int response = JOptionPane.showConfirmDialog(null, disclaimer, "Disclaimer", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (response != JOptionPane.OK_OPTION) {
            System.exit(0);
        }

      //JFrame frame = new JFrame("File to Base64 Encoder");
        JButton selectFileButton = new JButton("Seleccionar Archivo a codificar en BASE64");
        JButton decodeUnsaltedButton = new JButton("Decode Unsalted Base64");
        final JFrame frame = new JFrame("AES Base64 Cifrar/Descifrar");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new GridBagLayout());

        frame.add(selectFileButton);
        frame.setVisible(true);
        
        // Customize Layout
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(0, 0, 5, 5);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;

        gbc.gridx = 1;
        gbc.gridy = 6; // Adjust the grid position
        frame.add(decodeUnsaltedButton, gbc);

        // Create labels
        JLabel inputLabel = new JLabel("Texto a cifrar:");
        JLabel passwordLabel = new JLabel("Entrada Contraseña:");
        JLabel encryptedLabel = new JLabel("Cifrado (Base64):");
        JLabel decryptedLabel = new JLabel("Descifrado (Original):");

        // Customize text areas with titled borders
        final JTextArea inputTextArea = createStyledTextArea("Texto a cifrar");
        final JTextArea encryptedTextArea = createStyledTextArea("Cifrado (Base64)");
        final JTextArea decryptedTextArea = createStyledTextArea("Descifrado Text");

        // Password field
        final JPasswordField passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createTitledBorder("Contraseña"));

        // Buttons
        JButton encryptButton = createStyledButton("Cifrar/Contraseña");
        JButton encryptButtonSin = createStyledButton("Cifrar/SinContraseña");
        JButton decryptButton = createStyledButton("Descifrar");
        JButton clearButton = new JButton("Borrar Todo");

        // Add components to frame

        addComponentToFrame(frame, gbc, inputLabel, 0, 0, 2, 1);
        addComponentToFrame(frame, gbc, inputTextArea, 0, 1, 2, 1);
        addComponentToFrame(frame, gbc, passwordLabel, 0, 2, 1, 1);
        addComponentToFrame(frame, gbc, passwordField, 1, 2, 1, 1);
        addComponentToFrame(frame, gbc, encryptButton, 0, 3, 1, 1); // First button at column 0, row 3
        addComponentToFrame(frame, gbc, encryptButtonSin, 1, 3, 1, 1); // Second button at column 1, row 3
        addComponentToFrame(frame, gbc, encryptedLabel, 0, 4, 1, 1);
        addComponentToFrame(frame, gbc, encryptedTextArea, 0, 5, 2, 1);
        addComponentToFrame(frame, gbc, decryptButton, 0, 6, 1, 1);
        addComponentToFrame(frame, gbc, decryptedLabel, 0, 7, 2, 1);
        addComponentToFrame(frame, gbc, decryptedTextArea, 0, 8, 2, 1);
        addComponentToFrame(frame, gbc, clearButton, 0, 9, 0, 1);

        
        

        selectFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(frame);

                if (result == JFileChooser.APPROVE_OPTION) {
                    String filePath = fileChooser.getSelectedFile().getPath();
                    String base64Encoded = encodeFileToBase64(filePath);

                    if (base64Encoded != null) {
                        JOptionPane.showMessageDialog(frame, "Archivo cifrado en Base64!");
                        saveBase64ToFile(base64Encoded, "encoded_file.txt");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Error al codificar!.");
                    }
                }
            }
        });
        
      

        
        selectFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(frame);

                if (result == JFileChooser.APPROVE_OPTION) {
                    String filePath = fileChooser.getSelectedFile().getPath();
                    String base64Encoded = encodeFileToBase64(filePath);

                    if (base64Encoded != null) {
                        // Generate a unique filename for each encoded file
                        String uniqueFileName = getUniqueFileName("encoded_file", "txt");

                        // Save the Base64 string to the unique file
                        saveBase64ToFile(base64Encoded, uniqueFileName);

                        JOptionPane.showMessageDialog(frame, "Archivo cifrado en Base64 y guardado como: " + uniqueFileName);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Error al codificar!");
                    }
                }
            }
        });
      
        
        // Button actions
        encryptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String inputText = inputTextArea.getText();
                String password = new String(passwordField.getPassword());
                if (!inputText.isEmpty() && !password.isEmpty()) {
                    try {
                        String encryptedText = AESBase64EncryptDecryptGUI.encrypt(inputText, password);
                        encryptedTextArea.setText(encryptedText);
                        decryptedTextArea.setText("");
                      	logOperation("Encryption", inputText, encryptedText, password);
                        
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(frame, "Encryption Error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor haga entrada de texto y contraseña.");
                }
            }
        });
        
        // Button actions
        encryptButtonSin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String inputText = inputTextArea.getText();
                if (!inputText.isEmpty()) {
                    try {
                        String encryptedText = AESBase64EncryptDecryptGUI.encryptNoPassword(inputText);
                        encryptedTextArea.setText(encryptedText);
                        decryptedTextArea.setText("");
                        logOperation("Encryption (No Password)", inputText, encryptedText, "N/A");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(frame, "Encryption Error (No Password): " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter text to encrypt.");
                }
            }
        });

        encryptButtonSin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String inputText = inputTextArea.getText();
                if (!inputText.isEmpty()) {
                    try {
                        String encodedText = AESBase64EncryptDecryptGUI.encryptNoPassword(inputText);
                        encryptedTextArea.setText(encodedText);
                        decryptedTextArea.setText("");
                        logOperation("Base64 Encoding (No Password)", inputText, encodedText, "N/A");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(frame, "Base64 Encoding Error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter text to encode.");
                }
            }
        });

        

        decryptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String encryptedText = encryptedTextArea.getText();
                String password = new String(passwordField.getPassword());
                if (!encryptedText.isEmpty() && !password.isEmpty()) {
                    try {
                        String decryptedText = AESBase64EncryptDecryptGUI.decrypt(encryptedText, password);
                        decryptedTextArea.setText(decryptedText);
                        inputTextArea.setText("");
                        logOperation("Decryption", decryptedText, encryptedText, password);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(frame, "Decryption Error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor haga entrada de texto y contraseña.");
                }
            }
        });


      

	     // Add the action listener for decoding unsalted Base64
	     decodeUnsaltedButton.addActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent e) {
	             String encodedText = encryptedTextArea.getText(); // Assuming you use the same text area
	             if (!encodedText.isEmpty()) {
	                 try {
	                     String decodedText = decodeUnsaltedBase64(encodedText);
	                     decryptedTextArea.setText(decodedText); // Display the decoded text
	                     inputTextArea.setText(""); // Optionally clear the input
	                 } catch (IllegalArgumentException ex) {
	                     JOptionPane.showMessageDialog(frame, "Invalid Base64 input: " + ex.getMessage());
	                 }
	             } else {
	                 JOptionPane.showMessageDialog(frame, "Please enter Base64 text to decode.");
	             }
	         }
	     });

        
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearAllFields(inputTextArea, encryptedTextArea, decryptedTextArea, passwordField);
            }
        });


        frame.setVisible(true);
    } // main

}
